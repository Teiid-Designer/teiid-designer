#!/bin/bash

mvn clean install -P dev -Dmaven.repo.local="../m2-repository" &> build.log

