
-- drop the tables

drop Table g2;
drop Table g1;
  