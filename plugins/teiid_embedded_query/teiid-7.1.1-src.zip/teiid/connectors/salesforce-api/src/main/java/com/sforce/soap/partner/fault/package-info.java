@javax.xml.bind.annotation.XmlSchema(namespace = "urn:fault.partner.soap.sforce.com", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.sforce.soap.partner.fault;
