package org.teiid.arquillian;

public class SampleFunctions {
	
	public static int doSomething(String name) {
		return name.length();
	}

}
