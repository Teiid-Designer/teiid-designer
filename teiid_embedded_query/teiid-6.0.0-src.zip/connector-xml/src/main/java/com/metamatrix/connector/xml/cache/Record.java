package com.metamatrix.connector.xml.cache;

public interface Record {
	
	String getID();

	IDocumentCache getCache();

}
