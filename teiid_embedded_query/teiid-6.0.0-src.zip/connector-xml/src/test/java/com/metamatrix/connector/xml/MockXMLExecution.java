/*
 * JBoss, Home of Professional Open Source.
 * See the COPYRIGHT.txt file distributed with this work for information
 * regarding copyright ownership.  Some portions may be licensed
 * to Red Hat, Inc. under one or more contributor license agreements.
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 */



package com.metamatrix.connector.xml;

import org.mockito.Mockito;
import org.teiid.connector.api.ConnectorEnvironment;
import org.teiid.connector.api.ExecutionContext;
import org.teiid.connector.language.IQuery;
import org.teiid.connector.metadata.runtime.RuntimeMetadata;

import com.metamatrix.connector.xml.base.ExecutionInfo;
import com.metamatrix.connector.xml.base.XMLConnectionImpl;
import com.metamatrix.connector.xml.base.XMLExecutionImpl;

public class MockXMLExecution extends XMLExecutionImpl {
	
		private ExecutionInfo m_myInfo;
    	
    	public MockXMLExecution(XMLConnectionImpl conn,	RuntimeMetadata metadata) {
    		super(Mockito.mock(IQuery.class), conn, metadata, Mockito.mock(ExecutionContext.class), Mockito.mock(ConnectorEnvironment.class));
    		m_myInfo = new ExecutionInfo();
    	}
    	
    	public void setExecutionInfo(ExecutionInfo info) {
    		m_myInfo = info;
    	}
    	
    	public ExecutionInfo getInfo() {
    		return m_myInfo;
    	}
    }
