/*
 * ${license}
 */
package ${package-name};

import org.teiid.connector.basic.BasicManagedConnectionFactory;

public class ${connector-name}ManagedConnectionFactory extends BasicManagedConnectionFactory{
	
	// ra.xml files getters and setters go here.

}
